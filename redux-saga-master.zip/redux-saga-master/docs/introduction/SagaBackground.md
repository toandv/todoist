# Background on the Saga concept

**WIP**

For now, here are some useful links.

## External links

- [Applying the Saga Pattern (Youtube video)](https://www.youtube.com/watch?v=xDuwrtwYHu8) By Caitie McCaffrey
- [Original paper](http://www.cs.cornell.edu/andru/cs711/2002fa/reading/sagas.pdf) By Hector Garcia-Molina & Kenneth Salem
- [A Saga on Sagas](https://msdn.microsoft.com/en-us/library/jj591569.aspx) from MSDN site
