
import * as _api from './api'
import { browserHistory } from 'react-router'

export const api = _api
export const history = browserHistory
