# @redux-saga/types

Repository for shared types used by `redux-saga` packages. Shouldn't be used directly - its purpose is to avoid cyclic dependencies between `redux-saga` packages.
