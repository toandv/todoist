const saga = function* test1() {
  yield 1
}
