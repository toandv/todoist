function* test1() {
  yield* foo(1, 2, 3)
}
